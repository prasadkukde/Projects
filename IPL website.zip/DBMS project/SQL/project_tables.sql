-- All main tables
select * from batting_scorecard;
select * from bowling_scorecard;
select * from teams;
select * from seasons;
select * from Player;
select count(*) from Match_details;
select * from result;
select * from Scorecard;
select * from nrr;
select * from fall_of_wickets;
-- --------------------------------------------

update  bowling_scorecard set economy = economy *6;
-- Creating points table

drop view winner_temp;
drop view lose_temp;
drop table points_table;
drop procedure loop_all;

create view winner_temp as
select r.winner as team_name, count(*) as matches_won, 2*count(*) as points
from result r, seasons s, 
(select md.* from match_details md, seasons ss where md.season_id
= ss.season_id and ss.year = 2012 limit 4, 999999999) as m where 
r.match_id = m.match_id and s.year = 2012 group by r.winner;

create view lose_temp as
select r.loser as team_name, count(*) as matches_lost
from result r, seasons s, 
(select md.* from match_details md, seasons ss where md.season_id
= ss.season_id and ss.year = 2012 limit 4, 999999999) as m where 
r.match_id = m.match_id and s.year = 2012 group by r.loser;


create table points_table as
select winner_temp.team_name,
winner_temp.matches_won + lose_temp.matches_lost as total_matches,
 winner_temp.matches_won, lose_temp.matches_lost,
winner_temp.points, nrr.nrr from winner_temp, nrr, lose_temp, seasons s where
nrr.team_name = winner_temp.team_name and lose_temp.team_name = nrr.team_name 
and nrr.season_id = s.season_id and s.year = 2012
order by winner_temp.points desc, nrr.nrr desc;

alter table points_table add last_match int;
alter table points_table add last_2nd_match int;
alter table points_table add last_3rd_match int;
alter table points_table add last_4th_match int;
alter table points_table add last_5th_match int;
alter table points_table add pos int;

DELIMITER //
CREATE  PROCEDURE update_last5(in years int, in tname varchar(30))
BEGIN
    DECLARE done INT DEFAULT FALSE;
    DECLARE win varchar(30);
    DECLARE lose varchar(30);
    DECLARE count int;
    DECLARE cur CURSOR FOR 
    select r.winner, r.loser from result r, seasons s, 
	(select md.* from match_details md, seasons ss where 
    md.season_id = ss.season_id and ss.year = years limit 4, 999999999)
    as m where r.match_id = m.match_id and s.year = years ;
    DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = TRUE;
	set count = 0;
    OPEN cur;

    read_loop: LOOP
        FETCH cur INTO win, lose;
        IF done THEN
            LEAVE read_loop;
        END IF;
        if count = 0 then
			set count = count + 1;
			if win = tname then
				update points_table set last_match = 1 where team_name = tname;
			elseif lose = tname then
				update points_table set last_match = 0 where team_name = tname;
			else
				set count = count - 1;
            end if;
            
		elseif count = 1 then
			set count = count + 1;
			if win = tname then
				update points_table set last_2nd_match = 1 where team_name = tname;
			elseif lose = tname then
				update points_table set last_2nd_match = 0 where team_name = tname;
			else
				set count = count - 1;
            end if;
            
		elseif count = 2 then
			set count = count + 1;
			if win = tname then
				update points_table set last_3rd_match = 1 where team_name = tname;
			elseif lose = tname then
				update points_table set last_3rd_match = 0 where team_name = tname;
			else
				set count = count - 1;
            end if;
            
		elseif count = 3 then
			set count = count + 1;
			if win = tname then
				update points_table set last_4th_match = 1 where team_name = tname;
			elseif lose = tname then
				update points_table set last_4th_match = 0 where team_name = tname;
			else
				set count = count - 1;
            end if;
            
		elseif count = 4 then
			set count = count + 1;
			if win = tname then
				update points_table set last_5th_match = 1 where team_name = tname;
			elseif lose = tname then
				update points_table set last_5th_match = 0 where team_name = tname;
			else
				set count = count - 1;
            end if;
		end if;
		
    END LOOP;

    CLOSE cur;
END //

DELIMITER ;

drop procedure update_last5;

DELIMITER //
CREATE PROCEDURE loop_all ()
BEGIN
    DECLARE i INT DEFAULT 1;
	DECLARE tname varchar(30);
    WHILE i <= 15 DO
        select team_name into tname from teams where team_id = i;
		call  update_last5(2012, tname);
        SET i = i + 1;
    END WHILE;
END//
DELIMITER ;

select * from player;
drop procedure loop_all;
call loop_all();

    
SET @position := 0;
UPDATE points_table
SET pos = (@position := @position + 1);




-- -----------------------------------

-- season-wise player and team mapping

create table pts as
SELECT distinct s.season_id, p.player_id, t.team_id
FROM seasons s
JOIN
  (SELECT DISTINCT season_id, team1, team_name, team1players, teams.team_id
   FROM match_details
   JOIN teams ON match_details.team1 = teams.team_name) t
ON s.season_id = t.season_id
JOIN player p
ON t.team1players LIKE CONCAT('%', p.player_name, '%')
ORDER BY s.season_id, p.player_id;

select count(*) from pts;
select * from pts;

-- -------------------------------------
-- Finding orange cap 

-- Season-wise orange cap
select  season_id, player_name, team_name, total_runs as max_runs from (
select pts.season_id, t.team_name, p.player_name, sum(runs) as total_runs from batting_scorecard b,
player p, pts, match_details m, teams t, seasons s where pts.player_id = p.player_id and b.batsman = p.player_name 
and pts.season_id = s.season_id  and s.year = 2022 and m.match_id = b.match_id and m.season_id = pts.season_id 
and pts.team_id = t.team_id  and t.short = 'CSK' group by pts.season_id, b.batsman, t.team_name) rf GROUP BY season_id, player_name, team_name
ORDER BY season_id desc, max_runs DESC
LIMIT 15;

-- Orange cap holders for all seasons
create table orange_cap as
SELECT t.season_id, t.player_name, t.total_runs
FROM (
  SELECT pts.season_id, p.player_name, SUM(runs) AS total_runs
  FROM batting_scorecard b JOIN player p ON b.batsman = p.player_name
  JOIN pts ON pts.player_id = p.player_id JOIN match_details m 
  ON m.match_id = b.match_id AND m.season_id = pts.season_id
  GROUP BY pts.season_id, p.player_name) t
	JOIN 
(SELECT season_id, MAX(total_runs) AS max_runs FROM (SELECT pts.season_id,
    p.player_name, SUM(runs) AS total_runs FROM batting_scorecard b
    JOIN player p ON b.batsman = p.player_name JOIN pts ON pts.player_id =
    p.player_id JOIN match_details m ON m.match_id = b.match_id AND
    m.season_id = pts.season_id GROUP BY pts.season_id, p.player_name) x
  GROUP BY season_id) y 
ON t.season_id = y.season_id AND t.total_runs = y.max_runs 
order by t.season_id desc;

select * from orange_cap;


-- -------------------------------

-- Season-wise purple cap
select  season_id, team_name, player_name, total_wickets as max_wickets from (
select pts.season_id, t.team_name, p.player_name, sum(wickets) as total_wickets 
from bowling_scorecard b, player p, pts, match_details m, teams t, seasons s where 
pts.player_id = p.player_id and b.bowler = p.player_name and t.team_id = pts.team_id
and pts.season_id = s.season_id and s.year = 2022 and m.match_id = b.match_id and m.season_id = 
pts.season_id group by  s.season_id, b.bowler, t.team_name) rf GROUP BY season_id, player_name, team_name
ORDER BY max_wickets DESC
LIMIT 15;

-- All seasons purple cap holders

create table purple_cap as
SELECT t.season_id, t.player_name, t.total_wickets
FROM (
  SELECT pts.season_id, p.player_name, SUM(wickets) AS total_wickets
  FROM bowling_scorecard b
  JOIN player p ON b.bowler = p.player_name
  JOIN pts ON pts.player_id = p.player_id
  JOIN match_details m ON m.match_id = b.match_id AND m.season_id = pts.season_id
  GROUP BY pts.season_id, p.player_name
) t
JOIN (
  SELECT season_id, MAX(total_wickets) AS max_wickets
  FROM (
    SELECT pts.season_id, p.player_name, SUM(wickets) AS total_wickets
    FROM bowling_scorecard b
    JOIN player p ON b.bowler = p.player_name
    JOIN pts ON pts.player_id = p.player_id
    JOIN match_details m ON m.match_id = b.match_id AND m.season_id = pts.season_id
    GROUP BY pts.season_id, p.player_name
  ) x
  GROUP BY season_id
) y ON t.season_id = y.season_id AND t.total_wickets = y.max_wickets
order by t.season_id desc;

update purple_cap set total_wickets = 30 where season_id = 13;
delete from purple_cap where season_id = 12 and player_name = 'K Rabada';


select * from purple_cap;
select * from result;

-- -------------------------------
select * from batting_scorecard;
select * from bowling_scorecard;
-- Entire scorecard api

select   m.toss, m.venue, r.result_details
from match_details m, result r where  r.Match_id = m.match_id ;

select sc.Match_id, sc.inning_number, sc.name, t.short, sc.total_runs,
sc.total_wickets, sc.total_overs, sc.total_extras_runs, sc.lb, sc.wd, sc.byes, sc.nb
from scorecard sc, teams t, match_details m
 where t.team_name = sc.name and sc.match_id = m.match_id and 
(( m.team1 = 'Rajasthan Royals' and m.team2 = 'Delhi Capitals') or
( m.team2 = 'Rajasthan Royals' and m.team1 = 'Delhi Capitals'));


select match_id, inning_number, batsman, runs, balls_faced, fours, sixes,
runs/balls_faced*100 as sr, dismissal, wicket_bowler, wicket_fielder from (
select match_id, inning_number, batsman, runs, balls_faced, fours, sixes,
runs/balls_faced*100 as sr, dismissal, wicket_bowler, wicket_fielder,
row_number() over (partition by match_id, inning_number order by runs desc) as rn
from batting_scorecard
) as t
where rn <= 3 and match_id = 1254104 and Inning_Number = 1
order by match_id desc, inning_number asc, runs desc;


select match_id, inning_number, bowler, overs,  maidens, runs_conceded, wickets, economy from 
(
select match_id, inning_number, bowler, overs, maidens, runs_conceded, wickets, economy,
row_number() over (partition by match_id, inning_number order by wickets desc,
economy asc) as rn
from bowling_scorecard
) as t
where rn <= 3
order by match_id desc, inning_number asc, wickets desc, economy asc;


-- -----------------------------------------

-- fours
SELECT season_id, player_name, team_name, total_fours as max_fours
FROM (
    SELECT pts.season_id, t.team_name, p.player_name, SUM(b.fours) AS total_fours
    FROM batting_scorecard b, player p, pts, match_details m, teams t, seasons s
    WHERE pts.player_id = p.player_id
        AND b.batsman = p.player_name 
        AND pts.season_id = s.season_id 
        AND s.year = 2022 
        AND m.match_id = b.match_id 
        AND m.season_id = pts.season_id 
        AND pts.team_id = t.team_id 
    GROUP BY pts.season_id, b.batsman, t.team_name
) rf 
GROUP BY season_id, player_name, team_name
ORDER BY season_id DESC, max_fours DESC
LIMIT 15;

-- sixes

SELECT season_id, player_name, team_name, total_sixes as max_sixes
FROM (
    SELECT pts.season_id, t.team_name, p.player_name, SUM(b.sixes) AS total_sixes
    FROM batting_scorecard b, player p, pts, match_details m, teams t, seasons s
    WHERE pts.player_id = p.player_id
        AND b.batsman = p.player_name 
        AND pts.season_id = s.season_id 
        AND s.year = 2022 
        AND m.match_id = b.match_id 
        AND m.season_id = pts.season_id 
        AND pts.team_id = t.team_id 
    GROUP BY pts.season_id, b.batsman, t.team_name
) rf 
GROUP BY season_id, player_name, team_name
ORDER BY season_id DESC, max_sixes DESC
LIMIT 15;

-- strike rate
SELECT season_id, player_name, team_name, total_sr as max_sr
FROM (
    SELECT pts.season_id, t.team_name, p.player_name, sum(b.runs)/sum(b.
    balls_faced)* 100  AS total_sr
    FROM batting_scorecard b, player p, pts, match_details m, teams t, seasons s
    WHERE pts.player_id = p.player_id
        AND b.batsman = p.player_name 
        AND pts.season_id = s.season_id 
        AND s.year = 2022 
        AND m.match_id = b.match_id 
        AND m.season_id = pts.season_id 
        AND pts.team_id = t.team_id 
    GROUP BY pts.season_id, b.batsman, t.team_name
) rf 
GROUP BY season_id, player_name, team_name
ORDER BY season_id DESC, max_sr DESC
LIMIT 15;

-- highest score
SELECT season_id, player_name, team_name, MAX(runs) AS max_runs
FROM (
    SELECT pts.season_id, t.team_name, p.player_name, b.runs, m.match_id
    FROM batting_scorecard b, player p, pts, match_details m, teams t, seasons s
    WHERE pts.player_id = p.player_id
        AND b.batsman = p.player_name 
        AND pts.season_id = s.season_id 
        AND s.year = 2022 
        AND m.match_id = b.match_id 
        AND m.season_id = pts.season_id 
        AND pts.team_id = t.team_id 
    GROUP BY pts.season_id,  b.runs, b.batsman, t.team_name, m.match_id
) rf 
GROUP BY season_id, runs, player_name, team_name, match_id
ORDER BY season_id DESC, max_runs DESC
LIMIT 15;

-- most dots
SELECT season_id, player_name, team_name, total_dots as max_dots
FROM (
    SELECT pts.season_id, t.team_name, p.player_name, SUM(b.dots) AS total_dots
    FROM bowling_scorecard b, player p, pts, match_details m, teams t, seasons s
    WHERE pts.player_id = p.player_id
        AND b.bowler = p.player_name 
        AND pts.season_id = s.season_id 
        AND s.year = 2022 
        AND m.match_id = b.match_id 
        AND m.season_id = pts.season_id 
        AND pts.team_id = t.team_id 
    GROUP BY pts.season_id, b.bowler, t.team_name
) rf 
GROUP BY season_id, player_name, team_name
ORDER BY season_id DESC, max_dots DESC
LIMIT 15;

-- best economy
SELECT season_id, player_name, team_name, runs/balls*6 as max_economy
FROM (
    SELECT pts.season_id, t.team_name, p.player_name, SUM(b.Runs_Conceded) as runs,
    sum(floor(b.overs)* 6 + (b.overs - floor(b.overs))*10) as balls
    FROM bowling_scorecard b, player p, pts, match_details m, teams t, seasons s
    WHERE pts.player_id = p.player_id
        AND b.bowler = p.player_name 
        AND pts.season_id = s.season_id 
        AND s.year = 2022 
        AND m.match_id = b.match_id 
        AND m.season_id = pts.season_id 
        AND pts.team_id = t.team_id 
    GROUP BY pts.season_id, b.bowler, t.team_name
    having sum(floor(b.overs))>=4
) rf 
GROUP BY season_id, player_name, team_name
ORDER BY season_id DESC, max_economy asc
LIMIT 15;

-- highest wickets in an inning
select  season_id, team_name, player_name, total_wickets as max_wickets from (
select pts.season_id, t.team_name, p.player_name, max(b.wickets) as total_wickets 
from bowling_scorecard b, player p, pts, match_details m, teams t, seasons s where 
pts.player_id = p.player_id and b.bowler = p.player_name and t.team_id = pts.team_id
and pts.season_id = s.season_id and s.year = 2022 and m.match_id = b.match_id and m.season_id = 
pts.season_id group by  s.season_id, b.bowler, t.team_name) rf GROUP BY season_id, player_name, team_name
ORDER BY max_wickets DESC
LIMIT 15;

-- highest runs in an inning
select  season_id, player_name, team_name, total_runs as max_runs from (
select pts.season_id, t.team_name, p.player_name, max(runs) as total_runs from batting_scorecard b,
player p, pts, match_details m, teams t, seasons s where pts.player_id = p.player_id and b.batsman = p.player_name 
and pts.season_id = s.season_id  and s.year = 2013 and m.match_id = b.match_id and m.season_id = pts.season_id 
and pts.team_id = t.team_id  group by pts.season_id, b.batsman, t.team_name) rf GROUP BY season_id, player_name, team_name
ORDER BY season_id desc, max_runs DESC
LIMIT 15;



-- highest runs in all seasons
SELECT year, team_name, player_name, max(total_runs) as max_runs
FROM (
    SELECT s.year, t.team_name, p.player_name, max(b.runs) as total_runs
    FROM batting_scorecard b
    JOIN player p ON b.batsman = p.player_name
    JOIN pts ON pts.player_id = p.player_id
    JOIN match_details m ON m.match_id = b.match_id AND m.season_id = pts.season_id
    JOIN teams t ON t.team_id = pts.team_id
    JOIN seasons s ON pts.season_id = s.season_id

    GROUP BY b.batsman, t.team_name, s.year
) AS rf
GROUP BY team_name, player_name, year
ORDER BY max_runs DESC
LIMIT 15;


-- highest wickets in all seasons
SELECT year, team_name, player_name, max(total_wickets) as max_wickets
FROM (
    SELECT s.year, t.team_name, p.player_name, max(b.wickets) as total_wickets
    FROM bowling_scorecard b
    JOIN player p ON b.bowler = p.player_name
    JOIN pts ON pts.player_id = p.player_id
    JOIN match_details m ON m.match_id = b.match_id AND m.season_id = pts.season_id
    JOIN teams t ON t.team_id = pts.team_id
    JOIN seasons s ON pts.season_id = s.season_id

    GROUP BY b.bowler, t.team_name, s.year
) AS rf
GROUP BY team_name, player_name, year
ORDER BY max_wickets DESC
LIMIT 15;

select * from scorecard;

select name, total_runs from scorecard order by total_runs desc limit 15;

select name, total_runs from scorecard where inning_number = 2 order by total_runs desc limit 15;
-- -----------------------
select  p.player_name,  bt.runs , bt.balls_faced 
from batting_scorecard bt, player p , result r
where p.player_name = bt.batsman and r.man_of_match = p.player_name
and r.match_id = 1216521 and r.match_id = bt.match_id and
r.man_of_match = 'TA Boult' ;

select  p.player_name, bl.wickets, bl.runs_conceded
from bowling_scorecard bl, player p , result r
where p.player_name = bl.bowler and r.man_of_match = p.player_name
and r.match_id = 1216521 and r.match_id = bl.match_id and
r.man_of_match = 'TA Boult' ; 


-- -----------------------------------

-- for calculating best figures
SELECT p.player_name, MAX(CONCAT(wickets, '-', runs_conceded)) AS best_figures
FROM player p
LEFT JOIN bowling_scorecard b ON p.player_name = b.bowler
where bowler='V Kohli'
GROUP BY p.player_name;

-- getting number of hunderds for each batsman
SELECT p.player_name, IFNULL(SUM(IF(b.runs >= 100, 1, 0)), 0) AS centuries
FROM player p
LEFT JOIN batting_scorecard b ON p.player_name = b.batsman
GROUP BY p.player_name;

-- getting number of 4plus wicket haul
SELECT p.player_name, COALESCE(SUM(CASE WHEN b.wickets >= 4 THEN 1 ELSE 0 END), 0) AS four_wicket_branch
FROM player p
LEFT JOIN bowling_scorecard b ON p.player_name = b.bowler
GROUP BY p.player_name;
 



-- code for counting matches played by each_player

SELECT p.player_name, COUNT(DISTINCT combined_table.MATCH_ID) AS Matches_Played
FROM (
  SELECT MATCH_ID, Bowler AS Player_Name FROM bowling_scorecard
  UNION ALL
  SELECT MATCH_ID, Batsman AS Player_Name FROM batting_scorecard
) AS combined_table
JOIN player AS p ON combined_table.Player_Name = p.player_name
GROUP BY p.player_name;


#to get debut year

SELECT
  pname,
  YEAR(MIN(STR_TO_DATE(match_details.date, '%d-%m-%Y'))) AS debut_year
FROM (
  SELECT bowler as pname, Match_ID FROM bowling_scorecard WHERE bowler IN (SELECT player_name FROM player)
  UNION ALL
  SELECT batsman as pname , Match_id FROM batting_scorecard WHERE batsman IN (SELECT player_name FROM player)
) AS combined_scores
JOIN match_details ON combined_scores.Match_id = match_details.Match_id
GROUP BY pname;


-- batting strike rate
SELECT 
    player_name, 
    (SELECT (SUM(Runs) / SUM(balls_faced)) * 100 FROM batting_scorecard WHERE Batsman = player.player_name) AS batting_strike_rate
FROM player;


 -- get batting average

SELECT Batsman, (SUM(Runs) / COUNT(DISTINCT(match_id))) AS batting_average
FROM batting_scorecard
WHERE Batsman IN (SELECT DISTINCT(player_name) FROM player)
GROUP BY Batsman;

-- get bowling economy
SELECT bowler, SUM(runs_conceded) / (SUM(overs)) AS bowling_economy
FROM bowling_scorecard
GROUP BY bowler;


-- get total wickets, check once as showing excess
SELECT bowler, SUM(wickets) AS total_wickets
FROM bowling_scorecard
WHERE bowler IN (SELECT player_name FROM player)
GROUP BY bowler;

-- do player classification
 DELIMITER //
 CREATE PROCEDURE classify_players_now()
BEGIN
    DECLARE pname VARCHAR(60);
    DECLARE runs_scored INT;
    DECLARE wickets_taken INT;
    DECLARE bat_matches int;
    DECLARE bowl_matches int;
    DECLARE ptype VARCHAR(60);
    
    DECLARE player_cursor CURSOR FOR SELECT player_name FROM player;
    DECLARE CONTINUE HANDLER FOR NOT FOUND SET @finished = TRUE;
    
    OPEN player_cursor;
    
    player_loop: LOOP
        FETCH player_cursor INTO pname;
        
        IF @finished THEN
            LEAVE player_loop;
        END IF;
        
        
          SELECT SUM(runs), COUNT(*)
  INTO runs_scored, bat_matches
  FROM batting_scorecard
  WHERE batsman = pname;
  
  SELECT SUM(wickets), COUNT(*)
  INTO wickets_taken, bowl_matches
  FROM bowling_scorecard
  WHERE bowler = pname;
--         SELECT
--   (SELECT SUM(runs) into @runs_scored FROM batting_scorecard WHERE batsman = pname),
--   (SELECT COUNT(*) into @bat_matches FROM batting_scorecard WHERE batsman = pname) 
--   FROM batting_scorecard WHERE batsman = pname LIMIT 1;
--   
--     SELECT
--    (SELECT SUM(wickets) into @wickets_taken FROM bowling_scorecard WHERE bowler = pname),
--   (SELECT COUNT(*)  into @bowl_matches from bowling_scorecard WHERE bowler = pname)
--   FROM bowling_scorecard WHERE bowler = pname LIMIT 1;
      --  SET runs_scored = (SELECT SUM(runs) FROM batting_scorecard WHERE batsman = pname);
       -- SET wickets_taken = (SELECT SUM(wickets) FROM bowling_scorecard WHERE bowler = pname);
       -- set bat_matches = (SELECT count(*) from batting_scorecard where batsman = pname);
      --  set bowl_matches = (SELECT count(*) from bowling_scorecard where bowler = pname);
        
        IF runs_scored/bat_matches >= 20 AND wickets_taken/bowl_matches >= 1 THEN
            SET ptype = 'all-rounder';
        ELSEIF runs_scored/bat_matches >= 20 THEN
            SET ptype = 'batsman';
        ELSEIF wickets_taken/bowl_matches >= 1 THEN
            SET ptype = 'bowler';
        ELSE
            SET ptype = 'batsman';
        END IF;
        
        INSERT INTO PCT  VALUES (pname, ptype);
    END LOOP;
    
    CLOSE player_cursor;
END;
//

CALL classify_players_now();

DROP PROCEDURE classify_players_now;

SELECT* FROM PCT;
DROP TABLE PCT; 

CREATE TABLE PCT(
player_name VARCHAR(60),
player_type VARCHAR(60)
);


-- FIND HIGHEST SCORE
SELECT player.player_name, MAX(batting_scorecard.runs) AS highest_score
FROM player
JOIN PCT ON player.player_name = PCT.player_name
JOIN batting_scorecard ON player.player_name = batting_scorecard.batsman
WHERE PCT.player_type IN ('batsman', 'all-rounder')
GROUP BY player.player_name;

select* from PCT;

select* from bowling_scorecard;


select* from player;
SET SQL_SAFE_UPDATES=0;
DELETE FROM player where player_name='player_name';
select * from match_details;
select* from match_details where match_id=829763;
select* from batting_scorecard;
select name, total_runs from scorecard where inning_number = 2 order by total_runs desc limit 15;